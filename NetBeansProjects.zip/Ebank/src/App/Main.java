package App;

import Controller.Controller;


public class Main {

    public static void main(String[] args) {
        new Main().init();
    }
    private void init() {
        new Controller().run();
    }
}
