
package Utility;

import java.util.Scanner;

public class Tool {
    private Scanner sc;
    
    public Tool() {
        sc = new Scanner(System.in);
    }
    
    public int getInt() {
        try {
            return Integer.parseInt(sc.nextLine());
        } catch (Exception e) {
            System.out.println("Invalid Input. Try again: ");
            return getInt();
        }
    }
    
}
