
package Entities;

import Language.Bundle;
import View.View;

public class Ebank {
    public static final int ACC_LEN = 10;
    public static final int PWD_MIN_LEN = 8;
    public static final int PWD_MAX_LEN = 32;
    public void changeLanguage(int language) {
        switch (language) {
            case 1: // Vietnamese
                View.bundle.set(Bundle.VI);
                break;
            case 2: // English
                View.bundle.set(Bundle.EN);
                break;
        }
    }
    
    public boolean checkAccountNumber(String accountNumber) {
        return accountNumber.matches("^\\d{" + ACC_LEN + "}$");
    }
    
    public boolean checkPassword(String password) {
        return password.matches(".*\\d.*") && 
                    password.matches(".{" + PWD_MIN_LEN + "," + PWD_MAX_LEN + "}");
    }
    
    public String generateCaptcha() {
        int max_l = 10;
        int min_l = 5;
        int length = min_l + (int)(Math.random() * ((max_l - min_l) + 1));
        
        String captcha = "";
        for (int i = 0; i < length; i++) {
            char c = (char) (33 + (int)(Math.random() * 94));
            captcha += c;
        }
        return captcha;
    }
    
    public boolean checkCaptcha(String captcha, String input) {
        return captcha.compareTo(input) == 0;
    }
    
}
