
package Controller;

import Entities.Account;
import Entities.Ebank;
import Language.Bundle;
import Utility.Tool;
import View.View;
import static View.View.bundle;
import java.util.Scanner;

public class Controller {
    private boolean running;
    private Scanner sc;
    private View view;
    private Ebank ebank;
    private Tool tool;
    
    public Controller() {
        running = true;
        sc = new Scanner(System.in);
        view = new View();
        ebank = new Ebank();
        tool = new Tool();
    }
    
    public void run() {
        while (running) {
            view.showLogin();
            int option = tool.getInt();
            switch (option) {
                case 1: // Vietnamese
                case 2: // English
                    ebank.changeLanguage(option);
                    login();
                    break;
                default:
                    System.out.println(bundle.get("program_end"));;
                    running = false;
                    break;
            }
        }
    }
    
    public void login() {
        Account account = new Account();
        view.checkLogin(0);
        
        view.checkLogin(1);
        account.setAccountNumber(getAccountNumber());
        
        view.checkLogin(2);
        account.setPassword(getPassword());
        
        view.checkLogin(3);
        String captcha = ebank.generateCaptcha();
        System.out.print(captcha);
        
        view.checkLogin(4);
        getCaptcha(captcha);

    }
    
    public String getAccountNumber() {
        String number = sc.nextLine();
        // REGEX: exists a number with a fixed length of 10 (start 
        if (!ebank.checkAccountNumber(number)) {
            System.out.println(view.bundle.get("error_account_number")  + Ebank.ACC_LEN);
            System.out.println(view.bundle.get("try_again"));
            return getAccountNumber();
        }
        return number;
    }
    
    public String getPassword() {
        String password = sc.nextLine();
        // REGEX: exits a number with any type of data surroundings.
        if (!ebank.checkPassword(password)) {
            System.out.println(view.bundle.get("error_password") 
                    + Ebank.PWD_MIN_LEN + " - " + Ebank.PWD_MAX_LEN);
            System.out.println(view.bundle.get("try_again"));
            return getPassword();
        }
        return password;
    }
    
    public void getCaptcha(String captcha) {
        String input = sc.nextLine();
        if (!ebank.checkCaptcha(captcha, input)) {
            // Show error
            System.out.println(view.bundle.get("error_captcha"));
            // Show new Captcha
            view.checkLogin(3);
            captcha = ebank.generateCaptcha();
            System.out.print(captcha + "\n");
            // Asking for retype
            System.out.print(view.bundle.get("try_again"));
            getCaptcha(captcha); 
        }
    }
    
}
