
package Language;

import java.util.Locale;
import java.util.ResourceBundle;

public class Bundle {
    public static final int  EN = 0;
    public static final int  VI = 1;
    
    private ResourceBundle rs;
    private Locale lc;
    
    public void set(int lang) {
        String language = "";
        String country = "";
        switch (lang) {
            case EN:
                language = "en";
                country = "US";
                break;
            case VI:
                language = "vi";
                country = "VN";
                break;
        }
        String basename = "Language/Bundle_" + language;
        this.lc = new Locale(language, country);
        this.rs = ResourceBundle.getBundle(basename, lc);
    }

    public String get(String key) {
        return this.rs.getString(key);
    }
}
