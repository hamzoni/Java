
package View;

import Language.Bundle;

public class View {
    public static Bundle bundle;
    public View() {
        bundle = new Bundle();
        bundle.set(Bundle.EN);
    }
    
    public void showLogin() {
        System.out.println("\n" + bundle.get("login_ebank_system"));
        System.out.println("1. " + bundle.get("vietnamese"));
        System.out.println("2. " + bundle.get("english"));
        System.out.println("#. " + bundle.get("exit"));
        System.out.println(bundle.get("your_option"));
    }
    
    public void checkLogin(int type) {
        switch (type) {
            case 1:
                System.out.print("\n" + bundle.get("enter_account_number"));
                break;
            case 2:
                System.out.print("\n" + bundle.get("enter_password"));
                break;
            case 3:
                System.out.print("\n" + bundle.get("captcha"));
                break;
            case 4: 
                System.out.print("\n" + bundle.get("enter_captcha"));
                break;
            default:
                System.out.print("\n" + bundle.get("login_form"));
                break;
        }
    }
}
