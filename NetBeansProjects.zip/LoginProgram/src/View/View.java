
package View;

public class View {
    public void showMenu() {
        displayTitle("=", " Login Program ");
        System.out.println("1. Add User");
        System.out.println("2. Login");
        System.out.println("#. Exit");
        System.out.print("Your option: ");
    }
    public void displayTitle(String style, String title) {
        for (int i = 0; i < 5; i++)  System.out.print(style);
        System.out.print(title);
        for (int i = 0; i < 5; i++)  System.out.print(style);
        System.out.println();

    }
    public void addUser(int type) {
        switch (type) {
            case 1: // Account
                System.out.println("Account: ");
                break;
            case 2: // Password
            	System.out.println("Password: ");
                break;
            case 3: // Name
            	System.out.println("Name: ");
                break;
            case 4: // Phone
            	System.out.println("Phone: ");
                break;
            case 5: // Email
            	System.out.println("Email: ");
                break;
            case 6: // Address
            	System.out.println("Address: ");
                break;
            case 7: // DOB
            	System.out.println("DOB: ");
                break;
            default:
                displayTitle("-", " Add User ");
                break;
        }
    }
    public void login(int type) {
        
    }
    public void changePassword(int type) {
        switch (type) {
            case 1: // Account
                System.out.println("Account: ");
                break;
            case 2: // Password
            	System.out.println("Password: ");
                break;
            case 3: // Name
            	System.out.println("Name: ");
                break;
            case 4: // Phone
            	System.out.println("Phone: ");
                break;
            case 5: // Email
            	System.out.println("Email: ");
                break;
            case 6: // Address
            	System.out.println("Address: ");
                break;
            case 7: // DOB
            	System.out.println("DOB: ");
                break;
            default:
                displayTitle("-", " Add User ");
                break;
        }
    }
}
