
import Controller.Controller;


public class Main {

    public static void main(String[] args) {
        new Controller().run();
    }
    
}
